from . import base


class CallbackGame(base.TelegramObject):
    """
    A placeholder, currently holds no information. Use BotFather to set up your game.

    https://core.telegram.org/bots/api#callbackgame
    """
    pass
